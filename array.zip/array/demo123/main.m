//
//  main.m
//  demo123
//
//  Created by Yogesh Patel on 01/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSArray * array = [[NSArray alloc]initWithObjects:@"Hii",@"Hello",@"Hey", nil];
        
        NSLog(@"%@", array);
        
        NSMutableArray * arrdata = [[NSMutableArray alloc]initWithObjects:@"Hii",@"Hello",@"Hey", nil];
        [arrdata addObject:@"How Are You!!!"];
        [arrdata insertObject:@"Yo" atIndex:0];
        [arrdata removeObject:@"Yo"];
        [arrdata removeObjectAtIndex:1];
        [arrdata removeLastObject];
        [arrdata removeAllObjects];
        NSLog(@"%@", arrdata);
    }
    return 0;
}
